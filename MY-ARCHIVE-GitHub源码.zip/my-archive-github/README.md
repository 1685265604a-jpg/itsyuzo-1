# MY ARCHIVE · GitHub 导入版

HTML + CSS + 原生 JavaScript 照片画廊。支持 637 张照片浏览、3 张首页精选、拖动排序、手机移动排序、排版切换、间距调整、草稿与配置导入导出。保持原图比例，不压缩、不裁切。

这是**可上传到 GitHub 的源代码目录**，并非已上线网站。原图约 3 GB，超过 GitHub Pages 已发布站点 1 GB 的容量限制，因此网页放 GitHub Pages，原图放公开图片存储。原图包单独提供，未删除或降低原图质量。

## 一、导入 GitHub（网页上传）

1. 解压 `MY-ARCHIVE-GitHub源码.zip`。
2. 在 GitHub 点击 **New repository**，输入仓库名称，例如 `my-photo-archive`。普通免费 GitHub Pages 请选择 Public，默认分支使用 `main`。
3. 点击 **uploading an existing file** 或 **Add file → Upload files**。
4. 打开解压后的 `my-archive-github` 文件夹，把**里面的文件与子文件夹**上传到仓库根目录。不要只上传 ZIP，也不要多套一层 `my-archive-github` 目录。
5. 一定包含 `.github/workflows/pages.yml`。Mac Finder 用 **Command + Shift + .** 显示隐藏文件。若浏览器未上传隐藏目录，可在 GitHub 使用 **Add file → Create new file**，文件名填写 `.github/workflows/pages.yml`，粘贴交付包中该文件的完整内容。
6. 点击 **Commit changes**。此时网页代码已导入 GitHub。

GitHub 的 **Import repository** 页面用于导入其他 Git 仓库 URL，不是上传 ZIP 的入口。此包请使用 Upload files，或下面的 Git 命令。

也可通过终端上传（把 URL 换成自己的空仓库）：

```sh
git init -b main
git add .
git commit -m "Add photo archive website"
git remote add origin https://github.com/YOUR-NAME/YOUR-REPOSITORY.git
git push -u origin main
```

请在解压后的源码目录运行。若远端已存在内容，先 clone 该仓库，再把本包内容复制进去提交，不要强制覆盖现有分支。

## 二、准备原图地址

此步骤只在要正式公开网站时需要；仅把代码保存到 GitHub 可以先跳过。

1. 解压单独提供的 `MY-ARCHIVE-原图资源.zip`，得到 `assets/photos` 和 `assets/home-photos`。
2. 把 **assets 整个目录及内部结构**上传至自己的图片存储 / CDN，例如 Cloudflare R2、腾讯云 COS、阿里云 OSS 或现有网站空间。
3. 为这些图片启用公开读取的 HTTPS 域名。不可使用需要登录、会过期的预签名链接、网盘分享链接或 S3 管理 API endpoint。
4. 确认能在浏览器直接打开 `https://你的图片域名/assets/photos/IMG_6093.JPG`。
5. 不要启用强制裁切、自动低质量转换；网页会直接请求原始文件。

Cloudflare R2 可通过 Dashboard 配置公开域名；生产站点建议使用自定义域名。无需让 bucket 支持公开写入。这里只显示跨域图片，没有 canvas 操作，不需要额外开放写入 CORS。

若熟悉命令行，可安装 AWS CLI 并在本机配置存储凭据，再使用辅助脚本批量上传。凭据不要放进仓库：

```sh
python3 scripts/upload-originals.py --assets /原图解压位置/assets --bucket 你的bucket名称 --endpoint-url https://你的账户ID.r2.cloudflarestorage.com
```

脚本会验证全部 645 张原图的存在与大小，按原路径同步，不修改图片，不删除远端文件。先加 `--dry-run` 可查看计划；已配置多个账号时用 `--profile` 指定。

## 三、用 GitHub Pages 发布

1. 仓库 **Settings → Secrets and variables → Actions → Variables → New repository variable**。
2. Name 填写 `PHOTO_ASSET_BASE_URL`，Value 填写实际图片域名，例如 `https://img.你自己的域名.com`，**不包含末尾的 `/assets`**。域名可以带路径前缀，但应指向 assets 的上一级。
3. **Settings → Pages → Build and deployment → Source** 选择 **GitHub Actions**。
4. **Actions → Deploy gallery to GitHub Pages → Run workflow**。首次上传时若因尚未设置变量失败，设置后重跑即可。
5. 等待 build / deploy 成功。打开 Actions 输出或 Settings → Pages 显示的实际网址，通常是 `https://你的用户名.github.io/仓库名/`。

工作流只打包 `site`，不会把服务端源码作为网页发布，也不会上传 3 GB 原图。未填写图片地址时会明确报错，避免发布大量破图的页面。此包没有自动创建远程仓库或发布任何文件。

## 四、客户后续如何修改

在网页「编辑画廊」调整顺序、排版、间距、精选和文案，点击「导出配置文件」。将得到的 `site-config.js` 上传到仓库 **site** 文件夹，替换旧文件并提交。GitHub Actions 会自动重新发布，所有访客随后可见。

**GitHub Pages 只提供静态网页，不能直接用管理密码写入服务器。** 浏览器自动保存的草稿只对当前浏览器有效。客户若要完全在网页里点一次「发布」即可让所有人看到修改，应采用已包含的 Node.js / Cloudflare 服务端方案，参阅 `交付与上线说明.md`；此次 GitHub Pages 配置不会把这项能力伪装成已上线。

保留了 `server`、`wrangler.jsonc` 和 `package.json`，可继续使用之前的在线编辑部署方式。使用原 Cloudflare 方案前，需把完整原图恢复到 `site/assets`；这批本地原图被 `.gitignore` 忽略，不会提交到 GitHub。

## 五、本地预览

将原图包的 `assets` 文件夹复制到 `site/assets`，直接双击 `site/index.html`。默认配置使用本地图片。或在 Node.js 22+ 下运行：

```sh
node server/local.mjs
```

打开 `http://127.0.0.1:8787`。不需要安装 npm 依赖即可本地预览。部署工具仅在使用 Cloudflare 时需要安装。

## 目录

```text
.github/workflows/pages.yml  GitHub Pages 自动部署
site/index.html             网页入口
site/styles.css             样式
site/script.js              交互与客户编辑器
site/deployment-config.js   图片地址与 API 开关
site/site-config.js         照片顺序、排版和文案配置
site/gallery-data.js        浏览器图片目录
site/photo-manifest.json    原图尺寸与文件信息
scripts/prepare-pages.mjs   Pages 构建前配置检查
scripts/upload-originals.py 批量同步原图（可选）
server/                     原有在线保存服务
```

注意：不要把原图 ZIP 上传到 GitHub 仓库，不要使用 Git LFS 作为 GitHub Pages 图片托管。照片文件依然是交付的原始字节，图片存储与网页代码分开部署。
